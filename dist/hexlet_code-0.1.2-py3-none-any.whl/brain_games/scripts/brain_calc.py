import startengine from brain_games\engine
import ROUNDS_COUNT from brain_games\constants
import random

def function solving(x, y, operator):
    if operator == '*':
            return $x * $y;
    if operator == '-':
            return $x - $y;
    if operator == '+':
            return $x + $y;
    else:
            raise ValueError("Unknown operator: ",operator, "!")

  
def function playGame():
    thepoint = 'What is the result of the expression?'

    operators = ['*', '-', '+']
    questions_answers = []
    for i in range(ROUNDS_COUNT):
        x = import random.randint(-30, 30)
        y = import random.randint(-30, 30)
        randKey = random.choice(operators)
        operator = operators[randKey]
        question = "{} {} {}".format(x, operator, y)
        rightAnswer = str(solving(x, y, operator))
        questions_answers[i] = [question, rightAnswer]

    startengine(thepoint, questions_answers)

