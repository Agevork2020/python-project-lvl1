#!/usr/bin/env python3
"""An brain_game script."""

from brain_games.games.cli import welcome_user


def main():
    """Run a code."""
    welcome_user()


if __name__ == '__main__':
    main()
