"""Constants."""
ROUNDS_COUNT = 3
