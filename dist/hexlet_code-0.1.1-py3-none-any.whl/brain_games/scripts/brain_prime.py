import startengine from brain_games\engine
import ROUNDS_COUNT from brain_games\constants
import random

def function isPrime(x):
    if x < 2:
        return False
    list = [2: x / 2]
    for i in range(list):
        if x % i == 0:
            return False
    return True


def function playGame():
    thepoint = 'Answer "yes" if given number is prime. Otherwise answer "no".'

    questions_answers = []
    for i in range(ROUNDS_COUNT):
        question = random.randint(0, 100)
        rightAnswer = 'yes' if isPrime(question) else 'no'
        questions_answers[i] = [question, rightAnswer]

    startengine(thepoint, questions_answers)
